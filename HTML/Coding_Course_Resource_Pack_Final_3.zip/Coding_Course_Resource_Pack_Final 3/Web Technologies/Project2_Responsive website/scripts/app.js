﻿var app = (function () {
    /* Properties */
    var websiteName = "TRAVEL-NOW";
    /* Methods */
    return {
        getWebsiteName: function () {
            return websiteName;
        }
    }
})();
